package com.cg.carservice.service;
import com.cg.carservice.serviceDao.*;

import java.util.ArrayList;
import java.util.List;
import com.cg.carservice.bean.*;
import com.cg.carservice.exceptions.RegistrationNumberNotFound;
public class ServiceImpl implements Service{
	ServiceDao servicesDao = new ServiceDAOImpl();
	@Override
		public Car registerCustomer(String registrationNumber,long currentKms,String carName,String engineNumber,String chasisNumber,int totalServices,String ownerName,long mobileNumber) {
		int noOfServicesDone=0;
		int noOfServicesPending=totalServices;
		Car carDetails = new Car(registrationNumber,currentKms,carName,engineNumber,chasisNumber,totalServices,noOfServicesPending, noOfServicesPending, new Owner(ownerName,mobileNumber));
		Car carDetails2 = servicesDao.save(carDetails);
		return carDetails2;}
	@Override
		public Car carService(String registrationNumber) throws RegistrationNumberNotFound {
		Car carDetails = findOne(registrationNumber);
		carDetails.setNoOfServicesPending(carDetails.getNoOfServicesPending()-1);
		carDetails.setNoOfServicesDone(carDetails.getNoOfServicesDone()+1);
		carDetails.setKmsForNextService(carDetails.getCurrentKms()+5000);
		return carDetails;
		}
	@Override
		public Car findOne(String registrationNumber) throws RegistrationNumberNotFound {
		Car carCheck = servicesDao.update(registrationNumber);
		if(carCheck.equals(null)) throw new RegistrationNumberNotFound("Sorry this number is not registered with us");
			  return carCheck;
	}
	@Override
	public ArrayList<Car> getAll(){
		return servicesDao.findAll();
	}
}
