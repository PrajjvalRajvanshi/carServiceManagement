package com.cg.carservice.exceptions;

public class RegistrationNumberNotFound extends Exception{
public RegistrationNumberNotFound() {}
public RegistrationNumberNotFound(String message) {}
}
