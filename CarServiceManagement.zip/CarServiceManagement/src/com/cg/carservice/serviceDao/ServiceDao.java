package com.cg.carservice.serviceDao;

import java.util.ArrayList;

import com.cg.carservice.bean.Car;

public interface ServiceDao {
	public Car save(Car carDetails);
	public Car update(String registrationNumber);
	public ArrayList<Car>findAll();
}
