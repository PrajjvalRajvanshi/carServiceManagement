package com.cg.carservice.serviceDao;

import java.util.ArrayList;
import com.cg.carservice.DbUtil.CarServiceDbUtil;
import com.cg.carservice.bean.Car;

public class ServiceDAOImpl implements ServiceDao{

	@Override
	public Car save(Car carDetails) {
		return CarServiceDbUtil.carInfo.put(carDetails.getRegistrationNumber(), carDetails);
		}
	@Override
	public Car update(String registrationNumber) {
		return CarServiceDbUtil.carInfo.get(registrationNumber);}
	@Override
	public ArrayList<Car>findAll(){
		ArrayList CarDetails = new ArrayList<>(CarServiceDbUtil.carInfo.values());
		return CarDetails;
	}

}
