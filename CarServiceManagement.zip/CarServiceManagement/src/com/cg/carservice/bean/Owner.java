package com.cg.carservice.bean;

public class Owner {

private String ownerName;
private long mobileNumber;

public Owner() {}
public Owner(String ownerName, long mobileNumber) {
	super();
	this.ownerName = ownerName;
	this.mobileNumber = mobileNumber;
}
public String getOwnerName() {
	return ownerName;
}
public void setOwnerName(String ownerName) {
	this.ownerName = ownerName;
}
public long getMobileNumber() {
	return mobileNumber;
}
public void setMobileNumber(long mobileNumber) {
	this.mobileNumber = mobileNumber;
}
@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + (int) (mobileNumber ^ (mobileNumber >>> 32));
	result = prime * result + ((ownerName == null) ? 0 : ownerName.hashCode());
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Owner other = (Owner) obj;
	if (mobileNumber != other.mobileNumber)
		return false;
	if (ownerName == null) {
		if (other.ownerName != null)
			return false;
	} else if (!ownerName.equals(other.ownerName))
		return false;
	return true;
}
@Override
public String toString() {
	return "ownerName="  + ownerName + "\n "+"mobileNumber=" + mobileNumber ;
}

}
